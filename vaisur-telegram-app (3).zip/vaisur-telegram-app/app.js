const tg = window.Telegram?.WebApp;
if (tg) {
  tg.ready();
  tg.expand();
  tg.setHeaderColor('#0a0a0a');
  tg.setBackgroundColor('#0a0a0a');
  document.body.classList.add('tg-theme');
}

// ==================== НАСТРОЙКИ ====================
// Если бот и сайт на одном сервере — оставь так
// Если сайт отдельно — укажи полный адрес API, например: 'https://твой-бот.up.railway.app/api/products'
const PRODUCTS_URL = '/api/products';
// ===================================================

let products = [];
let cart = JSON.parse(localStorage.getItem('vaisur_cart') || '[]');
let currentCategory = 'all';
let selectedSize = null;
let currentProduct = null;

const productsEl = document.getElementById('products');
const cartCountEl = document.getElementById('cartCount');
const cartModal = document.getElementById('cartModal');
const productModal = document.getElementById('productModal');
const cartItemsEl = document.getElementById('cartItems');
const cartTotalEl = document.getElementById('cartTotal');
const toastEl = document.getElementById('toast');

// Загружаем товары при старте
loadProducts();
updateCartUI();

document.querySelectorAll('.cat-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentCategory = btn.dataset.cat;
    renderProducts();
  });
});

document.getElementById('cartBtn').addEventListener('click', () => {
  renderCart();
  cartModal.classList.add('open');
});

document.getElementById('closeCart').addEventListener('click', () => {
  cartModal.classList.remove('open');
});

document.getElementById('closeProduct').addEventListener('click', () => {
  productModal.classList.remove('open');
});

cartModal.addEventListener('click', (e) => {
  if (e.target === cartModal) cartModal.classList.remove('open');
});
productModal.addEventListener('click', (e) => {
  if (e.target === productModal) productModal.classList.remove('open');
});

document.getElementById('checkoutBtn').addEventListener('click', () => {
  if (cart.length === 0) return;

  const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0);

  let orderText = '🛒 Заказ VAISUR\n\n';
  cart.forEach(item => {
    orderText += `• ${item.name} (${item.size}) × ${item.qty} = ${item.price * item.qty} ₽\n`;
  });
  orderText += `\n💰 Итого: ${total.toLocaleString('ru-RU')} ₽`;

  if (tg) {
    tg.showPopup({
      title: 'Оформление заказа',
      message: 'Для продолжения напишите @VaisShop\n\nСейчас откроется чат с вашим заказом.',
      buttons: [
        { id: 'ok', type: 'default', text: 'Написать @VaisShop' }
      ]
    }, (btnId) => {
      if (btnId === 'ok') {
        const url = `https://t.me/VaisShop?text=${encodeURIComponent(orderText)}`;
        tg.openTelegramLink(url);
      }
    });
  } else {
    const url = `https://t.me/VaisShop?text=${encodeURIComponent(orderText)}`;
    window.open(url, '_blank');
  }

  cart = [];
  saveCart();
  updateCartUI();
  cartModal.classList.remove('open');
  showToast('Переходим к @VaisShop');
});

async function loadProducts() {
  try {
    const res = await fetch(PRODUCTS_URL + '?t=' + Date.now());
    if (res.ok) {
      products = await res.json();
    } else {
      products = [];
    }
  } catch (e) {
    console.log('Не удалось загрузить товары, каталог пуст');
    products = [];
  }
  renderProducts();
}

function renderProducts() {
  const filtered = currentCategory === 'all'
    ? products
    : products.filter(p => p.category === currentCategory);

  if (filtered.length === 0) {
    productsEl.innerHTML = `
      <div class="empty-catalog">
        <div class="empty-icon">🖤</div>
        <div class="empty-title">Каталог пуст</div>
        <div class="empty-text">Товары скоро появятся</div>
      </div>
    `;
    return;
  }

  productsEl.innerHTML = filtered.map(p => `
    <div class="product-card" data-id="${p.id}">
      <div class="product-image ${p.bg || 'bg-black'}">
        ${p.badge ? `<span class="badge">${p.badge}</span>` : ''}
        ${p.photo 
          ? `<img src="${p.photo}" alt="${p.name}" style="width:100%;height:100%;object-fit:cover;">`
          : `<span class="emoji">${p.emoji || '👕'}</span>`
        }
      </div>
      <div class="product-info">
        <div class="product-name">${p.name}</div>
        <div>
          <span class="product-price">${Number(p.price).toLocaleString('ru-RU')} ₽</span>
          ${p.oldPrice ? `<span class="product-old-price">${Number(p.oldPrice).toLocaleString('ru-RU')} ₽</span>` : ''}
        </div>
      </div>
    </div>
  `).join('');

  document.querySelectorAll('.product-card').forEach(card => {
    card.addEventListener('click', () => openProduct(+card.dataset.id));
  });
}

function openProduct(id) {
  currentProduct = products.find(p => p.id === id);
  if (!currentProduct) return;
  selectedSize = (currentProduct.sizes && currentProduct.sizes[0]) || 'ONE SIZE';

  const detail = document.getElementById('productDetail');
  detail.innerHTML = `
    <div class="product-detail-image ${currentProduct.bg || 'bg-black'}">
      ${currentProduct.badge ? `<span class="badge" style="top:16px;left:16px">${currentProduct.badge}</span>` : ''}
      ${currentProduct.photo 
        ? `<img src="${currentProduct.photo}" alt="${currentProduct.name}" style="width:100%;height:100%;object-fit:cover;">`
        : (currentProduct.emoji || '👕')
      }
    </div>
    <div class="product-detail-info">
      <div class="product-detail-name">${currentProduct.name}</div>
      <div class="product-detail-price">
        ${Number(currentProduct.price).toLocaleString('ru-RU')} ₽
        ${currentProduct.oldPrice ? `<span class="product-old-price" style="font-size:16px">${Number(currentProduct.oldPrice).toLocaleString('ru-RU')} ₽</span>` : ''}
      </div>
      <div class="product-detail-desc">${currentProduct.desc || ''}</div>
      <div class="size-selector">
        <div class="size-label">Размер</div>
        <div class="sizes">
          ${(currentProduct.sizes || ['ONE SIZE']).map(s => `
            <button class="size-btn ${s === selectedSize ? 'active' : ''}" data-size="${s}">${s}</button>
          `).join('')}
        </div>
      </div>
      <button class="add-to-cart-btn" id="addToCartBtn">Добавить в корзину</button>
    </div>
  `;

  detail.querySelectorAll('.size-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      detail.querySelectorAll('.size-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selectedSize = btn.dataset.size;
    });
  });

  document.getElementById('addToCartBtn').addEventListener('click', () => {
    addToCart(currentProduct, selectedSize);
    productModal.classList.remove('open');
    showToast('Добавлено в корзину');
  });

  productModal.classList.add('open');
}

function addToCart(product, size) {
  const existing = cart.find(i => i.id === product.id && i.size === size);
  if (existing) {
    existing.qty += 1;
  } else {
    cart.push({
      id: product.id,
      name: product.name,
      price: product.price,
      size: size,
      qty: 1,
      emoji: product.emoji || '👕',
      bg: product.bg || 'bg-black',
      photo: product.photo || null
    });
  }
  saveCart();
  updateCartUI();
}

function renderCart() {
  if (cart.length === 0) {
    cartItemsEl.innerHTML = `<div class="empty-cart">Корзина пуста</div>`;
    document.getElementById('checkoutBtn').disabled = true;
    cartTotalEl.textContent = '0';
    return;
  }

  document.getElementById('checkoutBtn').disabled = false;

  cartItemsEl.innerHTML = cart.map((item, idx) => `
    <div class="cart-item">
      <div class="cart-item-img ${item.bg || ''}">
        ${item.photo 
          ? `<img src="${item.photo}" style="width:100%;height:100%;object-fit:cover;border-radius:10px;">`
          : item.emoji
        }
      </div>
      <div class="cart-item-info">
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-price">${Number(item.price).toLocaleString('ru-RU')} ₽ · ${item.size}</div>
        <div class="cart-item-controls">
          <button class="qty-btn" data-action="minus" data-idx="${idx}">−</button>
          <span class="qty">${item.qty}</span>
          <button class="qty-btn" data-action="plus" data-idx="${idx}">+</button>
          <button class="remove-btn" data-idx="${idx}">Удалить</button>
        </div>
      </div>
    </div>
  `).join('');

  const total = cart.reduce((sum, i) => sum + i.price * i.qty, 0);
  cartTotalEl.textContent = total.toLocaleString('ru-RU');

  cartItemsEl.querySelectorAll('.qty-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = +btn.dataset.idx;
      if (btn.dataset.action === 'plus') {
        cart[idx].qty += 1;
      } else {
        cart[idx].qty -= 1;
        if (cart[idx].qty <= 0) cart.splice(idx, 1);
      }
      saveCart();
      updateCartUI();
      renderCart();
    });
  });

  cartItemsEl.querySelectorAll('.remove-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      cart.splice(+btn.dataset.idx, 1);
      saveCart();
      updateCartUI();
      renderCart();
    });
  });
}

function updateCartUI() {
  const count = cart.reduce((sum, i) => sum + i.qty, 0);
  cartCountEl.textContent = count;
  cartCountEl.dataset.count = count;
}

function saveCart() {
  localStorage.setItem('vaisur_cart', JSON.stringify(cart));
}

function showToast(msg) {
  toastEl.textContent = msg;
  toastEl.classList.add('show');
  setTimeout(() => toastEl.classList.remove('show'), 2200);
}
