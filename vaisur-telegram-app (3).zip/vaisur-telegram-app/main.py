import asyncio
import json
import logging
import os
from pathlib import Path

from aiohttp import web
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import (
    Message, 
    WebAppInfo, 
    InlineKeyboardMarkup, 
    InlineKeyboardButton,
    MenuButtonWebApp,
    FSInputFile,
    BufferedInputFile
)
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage

# ==================== НАСТРОЙКИ ====================
BOT_TOKEN = "9268320014:AAEMFu1ztGYuc1Tak7lGgT6xhkVKogPjY8o"
ADMIN_ID = 6902983109
WEBAPP_URL = "https://твой-сайт.pages.dev"  # Потом заменишь на реальную ссылку
# ===================================================

BASE_DIR = Path(__file__).parent
PRODUCTS_FILE = BASE_DIR / "products.json"
PHOTOS_DIR = BASE_DIR / "photos"
PHOTOS_DIR.mkdir(exist_ok=True)

logging.basicConfig(level=logging.INFO)
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())

# ---------- Хранилище товаров ----------
def load_products():
    if PRODUCTS_FILE.exists():
        with open(PRODUCTS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return []

def save_products(products):
    with open(PRODUCTS_FILE, "w", encoding="utf-8") as f:
        json.dump(products, f, ensure_ascii=False, indent=2)

# ---------- FSM для добавления товара ----------
class AddProduct(StatesGroup):
    waiting_photo = State()
    waiting_name = State()
    waiting_price = State()
    waiting_category = State()
    waiting_sizes = State()
    waiting_desc = State()

# ---------- Команды бота ----------
@dp.message(CommandStart())
async def cmd_start(message: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text="🖤 Открыть каталог VAISUR",
            web_app=WebAppInfo(url=WEBAPP_URL)
        )]
    ])
    await message.answer(
        "<b>VAISUR</b>\n\n"
        "Уличная эстетика. Чистые линии. Твой стиль.\n\n"
        "Нажми кнопку, чтобы открыть каталог:",
        reply_markup=kb,
        parse_mode="HTML"
    )

@dp.message(Command("admin"))
async def cmd_admin(message: Message):
    if message.from_user.id != ADMIN_ID:
        return await message.answer("Нет доступа")
    
    await message.answer(
        "🛠 <b>Админ-панель VAISUR</b>\n\n"
        "<b>Команды:</b>\n"
        "/add — добавить товар\n"
        "/list — список товаров\n"
        "/delete ID — удалить товар\n"
        "/clear — очистить весь каталог",
        parse_mode="HTML"
    )

@dp.message(Command("list"))
async def cmd_list(message: Message):
    if message.from_user.id != ADMIN_ID:
        return
    products = load_products()
    if not products:
        return await message.answer("Каталог пуст")
    
    text = "📦 <b>Товары в каталоге:</b>\n\n"
    for p in products:
        text += f"<b>#{p['id']}</b> {p['name']} — {p['price']} ₽\n"
    await message.answer(text, parse_mode="HTML")

@dp.message(Command("delete"))
async def cmd_delete(message: Message):
    if message.from_user.id != ADMIN_ID:
        return
    try:
        product_id = int(message.text.split()[1])
    except:
        return await message.answer("Использование: /delete 3")
    
    products = load_products()
    new_products = [p for p in products if p["id"] != product_id]
    if len(new_products) == len(products):
        return await message.answer("Товар не найден")
    
    save_products(new_products)
    await message.answer(f"✅ Товар #{product_id} удалён")

@dp.message(Command("clear"))
async def cmd_clear(message: Message):
    if message.from_user.id != ADMIN_ID:
        return
    save_products([])
    await message.answer("✅ Каталог полностью очищен")

@dp.message(Command("add"))
async def cmd_add(message: Message, state: FSMContext):
    if message.from_user.id != ADMIN_ID:
        return
    await state.set_state(AddProduct.waiting_photo)
    await message.answer("📷 Пришли <b>фото</b> товара", parse_mode="HTML")

@dp.message(AddProduct.waiting_photo, F.photo)
async def process_photo(message: Message, state: FSMContext):
    photo = message.photo[-1]
    file = await bot.get_file(photo.file_id)
    photo_path = PHOTOS_DIR / f"{photo.file_id}.jpg"
    
    await bot.download_file(file.file_path, photo_path)
    
    # Сохраняем относительный путь (будет отдаваться через /photos/)
    await state.update_data(photo=f"/photos/{photo.file_id}.jpg", file_id=photo.file_id)
    await state.set_state(AddProduct.waiting_name)
    await message.answer("✏️ Напиши <b>название</b> товара", parse_mode="HTML")

@dp.message(AddProduct.waiting_name)
async def process_name(message: Message, state: FSMContext):
    await state.update_data(name=message.text.strip())
    await state.set_state(AddProduct.waiting_price)
    await message.answer("💰 Напиши <b>цену</b> (только число, например 4990)", parse_mode="HTML")

@dp.message(AddProduct.waiting_price)
async def process_price(message: Message, state: FSMContext):
    try:
        price = int(message.text.strip().replace(" ", "").replace("₽", ""))
    except:
        return await message.answer("Напиши цену числом, например: 4990")
    
    await state.update_data(price=price)
    await state.set_state(AddProduct.waiting_category)
    await message.answer(
        "🏷 Выбери <b>категорию</b>:\n\n"
        "1 — Худи\n"
        "2 — Футболки\n"
        "3 — Штаны\n"
        "4 — Аксессуары\n\n"
        "Напиши цифру:",
        parse_mode="HTML"
    )

@dp.message(AddProduct.waiting_category)
async def process_category(message: Message, state: FSMContext):
    cats = {
        "1": "hoodies",
        "2": "tshirts",
        "3": "pants",
        "4": "accessories"
    }
    cat = cats.get(message.text.strip())
    if not cat:
        return await message.answer("Напиши цифру от 1 до 4")
    
    await state.update_data(category=cat)
    await state.set_state(AddProduct.waiting_sizes)
    await message.answer(
        "📏 Напиши размеры через запятую\n"
        "Например: S, M, L, XL\n"
        "Или: ONE SIZE"
    )

@dp.message(AddProduct.waiting_sizes)
async def process_sizes(message: Message, state: FSMContext):
    sizes = [s.strip().upper() for s in message.text.split(",")]
    await state.update_data(sizes=sizes)
    await state.set_state(AddProduct.waiting_desc)
    await message.answer("📝 Напиши короткое <b>описание</b> товара\n(или отправь «-» если без описания)", parse_mode="HTML")

@dp.message(AddProduct.waiting_desc)
async def process_desc(message: Message, state: FSMContext):
    data = await state.get_data()
    desc = message.text.strip()
    if desc == "-":
        desc = ""
    
    products = load_products()
    new_id = max([p["id"] for p in products], default=0) + 1
    
    product = {
        "id": new_id,
        "name": data["name"],
        "price": data["price"],
        "category": data["category"],
        "sizes": data["sizes"],
        "desc": desc,
        "photo": data["photo"],
        "emoji": "🖤",
        "bg": "bg-black"
    }
    
    products.append(product)
    save_products(products)
    
    await state.clear()
    await message.answer(
        f"✅ Товар добавлен!\n\n"
        f"<b>#{new_id}</b> {product['name']}\n"
        f"Цена: {product['price']} ₽\n"
        f"Категория: {product['category']}",
        parse_mode="HTML"
    )

# ---------- Web-сервер (раздаёт сайт + API) ----------
async def api_products(request):
    products = load_products()
    return web.json_response(products)

async def serve_photo(request):
    filename = request.match_info["filename"]
    path = PHOTOS_DIR / filename
    if not path.exists():
        return web.Response(status=404)
    return web.FileResponse(path)

async def index(request):
    return web.FileResponse(BASE_DIR / "index.html")

async def static_file(request):
    name = request.match_info["name"]
    path = BASE_DIR / name
    if path.exists() and path.is_file():
        return web.FileResponse(path)
    return web.Response(status=404)

async def on_startup(app):
    await bot.set_chat_menu_button(
        menu_button=MenuButtonWebApp(
            text="Каталог",
            web_app=WebAppInfo(url=WEBAPP_URL)
        )
    )
    logging.info("Бот и сервер запущены")

async def main():
    # HTTP-приложение
    app = web.Application()
    app.router.add_get("/", index)
    app.router.add_get("/api/products", api_products)
    app.router.add_get("/photos/{filename}", serve_photo)
    app.router.add_get("/{name}", static_file)
    
    # Запускаем polling бота + веб-сервер
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", int(os.getenv("PORT", 8080)))
    await site.start()
    
    await on_startup(app)
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
